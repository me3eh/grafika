class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def values(self):
        return [self.x, self.y]

